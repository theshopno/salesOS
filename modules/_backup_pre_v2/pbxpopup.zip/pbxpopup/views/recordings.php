<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper">
    <div class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="_buttons">
                    <a href="<?= admin_url('leads/index/' . $lead->id) ?>" class="btn btn-default pull-left">
                        <i class="fa fa-arrow-left"></i> Back to Lead
                    </a>
                </div>
                <div class="clearfix"></div>
                <hr class="hr-panel-heading" />

                <h4><i class="fa fa-headphones"></i> Call Recordings - <?= htmlspecialchars($lead->name) ?></h4>
                <p class="text-muted"><?= htmlspecialchars($lead->phonenumber) ?> &middot; স্ট্রিম করা হচ্ছে সরাসরি PBX থেকে, লাইভ</p>

                <?php if ($error): ?>
                    <div class="alert alert-warning"><?= htmlspecialchars($error) ?></div>
                <?php elseif (empty($recordings)): ?>
                    <div class="alert alert-default">এই নম্বরে কোনো কল রেকর্ডিং পাওয়া যায়নি।</div>
                <?php else: ?>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>তারিখ/সময়</th>
                                <th>ধরন</th>
                                <th>স্থিতিকাল</th>
                                <th style="width: 340px;">প্লেয়ার</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($recordings as $rec): ?>
                            <?php
                                $mins = floor($rec['duration'] / 60);
                                $secs = $rec['duration'] % 60;
                                $sig = hash_hmac('sha256', $rec['uniqueid'] . '|' . $rec['namefile'], PBXBRIDGE_API_TOKEN);
                                $streamUrl = base_url('modules/pbxpopup/stream.php') . '?' . http_build_query([
                                    'id'       => $rec['uniqueid'],
                                    'namefile' => $rec['namefile'],
                                    'sig'      => $sig,
                                ]);
                            ?>
                            <tr>
                                <td><?= htmlspecialchars($rec['calldate']) ?></td>
                                <td>
                                    <?php if ($rec['disposition'] !== 'ANSWERED'): ?>
                                        <span class="label label-default"><?= htmlspecialchars($rec['disposition']) ?></span>
                                    <?php else: ?>
                                        <span class="label label-success">Answered</span>
                                    <?php endif; ?>
                                </td>
                                <td><?= sprintf('%d:%02d', $mins, $secs) ?></td>
                                <td>
                                    <audio controls preload="none" style="width: 320px; height: 34px;" src="<?= $streamUrl ?>"></audio>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
</body>
</html>
