<?php
/*
 * Standalone audio streaming proxy for the Call Recordings tab.
 *
 * Deliberately bypasses the CI/Perfex framework entirely, the same way
 * bridge.php on the PBX side bypasses Issabel's - MVC output buffering
 * does not play well with raw binary streaming plus manual Range headers.
 *
 * Auth is a short-lived HMAC signature minted by Pbxpopup::recordings()
 * (a real, session-authenticated CI controller) when it builds the page,
 * not a session cookie - this script never touches the session system.
 *
 * Streams chunk-by-chunk as bytes arrive from the PBX instead of
 * buffering the whole file first - the PBX's home/office uplink is slow
 * (measured ~80KB/s), so a multi-minute recording can take well over a
 * minute to fully transfer. Buffering the whole thing hit curl's/PHP's
 * timeouts before a single byte reached the browser. True streaming lets
 * playback start as soon as the first chunk arrives (audio bitrate here
 * is well under the measured transfer speed, so it keeps up in real time).
 */

define('PBXBRIDGE_URL', 'https://pbx.uddoktayon.com/modules/monitoring/bridge.php');
define('PBXBRIDGE_API_TOKEN', '4a5dd83bf0e66bebfa19d64932fa9c068a18c67f6f38781df9891b1995409f42');

set_time_limit(0);

$uniqueid = isset($_GET['id']) ? $_GET['id'] : '';
$namefile = isset($_GET['namefile']) ? $_GET['namefile'] : '';
$sig      = isset($_GET['sig']) ? $_GET['sig'] : '';

$expected = hash_hmac('sha256', $uniqueid . '|' . $namefile, PBXBRIDGE_API_TOKEN);
if ($uniqueid === '' || $namefile === '' || !hash_equals($expected, (string) $sig)) {
    http_response_code(403);
    die('invalid signature');
}

$url = PBXBRIDGE_URL . '?' . http_build_query([
    'action'   => 'stream',
    'id'       => $uniqueid,
    'namefile' => $namefile,
    'token'    => PBXBRIDGE_API_TOKEN,
]);

$statusLine  = null;
$headersSent = false;

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_TIMEOUT, 0);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
// Abort only on a genuine stall (near-zero throughput for 20s straight),
// not on total elapsed time - a slow-but-steady transfer must be allowed
// to run as long as it takes.
curl_setopt($ch, CURLOPT_LOW_SPEED_LIMIT, 500);
curl_setopt($ch, CURLOPT_LOW_SPEED_TIME, 20);
if (isset($_SERVER['HTTP_RANGE'])) {
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Range: ' . $_SERVER['HTTP_RANGE']]);
}

curl_setopt($ch, CURLOPT_HEADERFUNCTION, function ($curl, $headerLine) use (&$statusLine) {
    $trimmed = trim($headerLine);
    if ($trimmed === '') {
        return strlen($headerLine);
    }
    if (stripos($trimmed, 'HTTP/') === 0) {
        $statusLine = $trimmed;
    } elseif (stripos($trimmed, 'Content-Type:') === 0
        || stripos($trimmed, 'Content-Length:') === 0
        || stripos($trimmed, 'Content-Range:') === 0
        || stripos($trimmed, 'Accept-Ranges:') === 0) {
        header($trimmed);
    }
    return strlen($headerLine);
});

curl_setopt($ch, CURLOPT_WRITEFUNCTION, function ($curl, $chunk) use (&$headersSent, &$statusLine) {
    if (!$headersSent) {
        if ($statusLine !== null && strpos($statusLine, '206') !== false) {
            http_response_code(206);
        } elseif ($statusLine !== null && strpos($statusLine, '404') !== false) {
            http_response_code(404);
        } elseif ($statusLine !== null && strpos($statusLine, '403') !== false) {
            http_response_code(403);
        }
        $headersSent = true;
    }
    echo $chunk;
    flush();
    return strlen($chunk);
});

curl_exec($ch);
$errno = curl_errno($ch);
$error = curl_error($ch);
curl_close($ch);

if ($errno && !$headersSent) {
    http_response_code(502);
    echo 'PBX unreachable: ' . $error;
}
