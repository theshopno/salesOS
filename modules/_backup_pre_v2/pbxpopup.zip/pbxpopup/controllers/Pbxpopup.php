<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Pbxpopup extends AdminController
{
    public function __construct()
    {
        parent::__construct();

        if (!is_staff_member()) {
            access_denied('PBX Popup');
        }
    }

    /**
     * GET /admin/pbxpopup/find?phone=<raw caller id>
     * MicroSIP's cmdIncomingCall opens this URL with the caller's number.
     * Redirects straight to the matching lead/customer; falls back to a
     * search-results page when nothing matches confidently.
     */
    public function find()
    {
        $raw    = (string) $this->input->get('phone');
        $digits = preg_replace('/\D/', '', $raw);
        $last10 = substr($digits, -10);

        if (strlen($last10) < 7) {
            redirect(admin_url('leads'));
            return;
        }

        // Self-contained lookup (no dependency on the pbxpilot module -
        // this must keep working whether or not pbxpilot is active).
        $link = $this->_find_contact_link($last10);

        if ($link) {
            redirect($link);
            return;
        }

        // No confident match - show Perfex's own global search results for
        // this number instead of guessing.
        $this->load->model('misc_model');
        $data['phone']   = $raw;
        $data['digits']  = $last10;
        $data['results'] = $this->misc_model->perform_search($last10);
        $data['title']   = 'PBX Popup';
        $this->load->view('results', $data);
    }

    /**
     * Exact match on the last 10 digits (tolerant of stray spaces/dashes
     * and of the +880/880/0 country-code variants). Checks leads, then
     * clients, then client contacts. Returns an admin_url() link or null.
     */
    private function _find_contact_link($last10)
    {
        $norm = "RIGHT(REPLACE(REPLACE(phonenumber,' ',''),'-',''), 10)";

        $lead = $this->db->query(
            'SELECT id FROM ' . db_prefix() . "leads
             WHERE $norm = ?
             ORDER BY dateadded DESC LIMIT 1",
            [$last10]
        )->row();
        if ($lead) {
            return admin_url('leads/index/' . $lead->id);
        }

        $client = $this->db->query(
            'SELECT userid FROM ' . db_prefix() . "clients
             WHERE $norm = ?
             ORDER BY userid DESC LIMIT 1",
            [$last10]
        )->row();
        if ($client) {
            return admin_url('clients/client/' . $client->userid);
        }

        $contact = $this->db->query(
            'SELECT userid FROM ' . db_prefix() . "contacts
             WHERE $norm = ?
             ORDER BY id DESC LIMIT 1",
            [$last10]
        )->row();
        if ($contact) {
            return admin_url('clients/client/' . $contact->userid);
        }

        return null;
    }

    /**
     * GET /admin/pbxpopup/recordings/<lead_id>
     * Lists this lead's call recordings, fetched live from the PBX bridge
     * API. Nothing is stored on the CRM side - every play streams straight
     * from the PBX on demand.
     */
    public function recordings($lead_id)
    {
        $lead = $this->db->where('id', $lead_id)->get(db_prefix() . 'leads')->row();
        if (!$lead) {
            show_404();
            return;
        }

        $data['lead']        = $lead;
        $data['title']       = 'Call Recordings - ' . $lead->name;
        $data['recordings']  = [];
        $data['error']       = null;

        $digits = preg_replace('/\D/', '', (string) $lead->phonenumber);
        $last10 = substr($digits, -10);

        if (strlen($last10) < 7) {
            $data['error'] = 'এই লিডের কোনো ফোন নম্বর সেভ করা নেই।';
        } else {
            $result = $this->_bridge_request('list', ['phone' => $last10]);
            if ($result === null) {
                $data['error'] = 'PBX-এর সাথে যোগাযোগ করা যাচ্ছে না (অফলাইন থাকতে পারে)। কিছুক্ষণ পর আবার চেষ্টা করুন।';
            } else {
                $data['recordings'] = isset($result['recordings']) ? $result['recordings'] : [];
            }
        }

        $this->load->view('recordings', $data);
    }

    /**
     * Short timeouts on purpose - the Lead page (and this page) must not
     * hang if the PBX is offline, it should just show a graceful error.
     */
    private function _bridge_request($action, $params)
    {
        $params['action'] = $action;
        $params['token']  = PBXBRIDGE_API_TOKEN;
        $url = PBXBRIDGE_URL . '?' . http_build_query($params);

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 6);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 4);
        $response   = curl_exec($ch);
        $statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($response === false || $statusCode !== 200) {
            return null;
        }
        $decoded = json_decode($response, true);
        return is_array($decoded) ? $decoded : null;
    }
}
