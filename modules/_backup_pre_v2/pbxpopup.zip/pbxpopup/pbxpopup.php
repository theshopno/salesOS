<?php

defined('BASEPATH') or exit('No direct script access allowed');

/*
Module Name: PBX Popup - Call Screen Pop
Description: Looks up an incoming caller's number against Leads/Customers and opens the matching record. Also adds a Call Recordings tab to the Lead page that streams recordings live from the PBX. Called from MicroSIP's incoming-call URL action.
Version: 1.0.0
Requires at least: 2.3.2
Developer: Uddoktayon
*/

define('PBXPOPUP_MODULE_NAME', 'pbxpopup');

// Shared secret with /var/www/html/modules/monitoring/bridge.php on the
// Issabel box - authenticates server-to-server requests that have no
// Issabel session (there is no browser involved on this side).
define('PBXBRIDGE_URL', 'https://pbx.uddoktayon.com/modules/monitoring/bridge.php');
define('PBXBRIDGE_API_TOKEN', '4a5dd83bf0e66bebfa19d64932fa9c068a18c67f6f38781df9891b1995409f42');

hooks()->add_action('after_lead_lead_tabs', 'pbxpopup_add_lead_tab');

/**
 * Adds a "Call Recordings" tab link to the Lead page's tab bar. Follows
 * the same pattern as the meetings module: a plain link to a dedicated
 * page rather than an in-page tab-content pane.
 */
function pbxpopup_add_lead_tab($lead)
{
    if ($lead) {
        echo '<li role="presentation">
            <a href="' . admin_url('pbxpopup/recordings/' . $lead->id) . '">
                <i class="fa fa-headphones menu-icon" aria-hidden="true"></i> Call Recordings
            </a>
        </li>';
    }
}
